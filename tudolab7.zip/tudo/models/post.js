
const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
    titulo: String,
    resumo: String,
    conteudo: String
});

module.exports = mongoose.model('Post', PostSchema);