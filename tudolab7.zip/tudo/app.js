const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const colors = require("colors");

const app = express();
const Post = require('./models/Post');

// Configurações
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Conexão com MongoDB
mongoose.connect('mongodb://localhost:27017')
    .then(() => console.log('MongoDB conectado!'))
    .catch(err => console.log(err));

// Página inicial: Projects
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Projects.html'));
});

// Página do blog: busca todos os posts
app.get('/blog', async (req, res) => {
    try {
        const posts = await Post.find();
        res.render('blog', { posts: posts });
    } catch (err) {
        res.status(500).send('Erro ao buscar posts.');
    }
});

app.use(express.urlencoded({ extended: true }));

// Página de cadastro
app.get('/cadastrar-post', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cadastrar_post.html'));
});

// Cadastrar post no banco
app.post('/cadastrar-post', async (req, res) => {
    try {
        const novoPost = new Post({
            titulo: req.body.titulo,
            resumo: req.body.resumo,
            conteudo: req.body.conteudo
        });

        await novoPost.save();

        // Depois de salvar, abre a confirmação
        res.redirect('/post-cadastrado');

    } catch (err) {
        console.log('Erro ao cadastrar:', err);
        res.status(500).send('Erro ao cadastrar post.');
    }
});

// Página de confirmação
app.get('/post-cadastrado', (req, res) => {
    res.render('post_cadastrado');
});

app.use(express.urlencoded({ extended: true }));

// Servidor na porta 80
app.listen(80, () => {
    console.log('Servidor rodando na porta 80!'. rainbow);
});